import React, { useLayoutEffect, useState } from "react";
import "./ShareCreation.scss";

interface ShareCreationProps {}

export const ShareCreation: React.FC<ShareCreationProps> = () => {
    return (
        <>
            <h1>share creation</h1>
        </>
    );
};
